import asyncio
import json
import os
import sys
import edge_tts

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PUBLIC_DIR = os.path.join(PROJECT_ROOT, "public")
UNIT_PATH = os.path.join(PROJECT_ROOT, "data", "units", "en", "a2", "unit_03_shopping.json")
VOICE = "en-GB-RyanNeural"


async def generate_speech(text: str, voice: str, out_path: str):
    normalized = os.path.normpath(out_path)
    os.makedirs(os.path.dirname(normalized), exist_ok=True)

    if os.path.exists(normalized) and os.path.getsize(normalized) > 0:
        print(f"  [ПРОПУСК] Уже есть: {os.path.relpath(normalized, PROJECT_ROOT)}")
        return

    try:
        communicate = edge_tts.Communicate(text, voice)
        await asyncio.wait_for(communicate.save(normalized), timeout=15.0)
        print(f"  [ГОТОВО] '{text}' -> {os.path.relpath(normalized, PROJECT_ROOT)}")
    except Exception as err:
        print(f"  [ОШИБКА] для '{text}': {err}")


async def main():
    if not os.path.exists(UNIT_PATH):
        print(f"[ОШИБКА] Файл урока не найден: {UNIT_PATH}")
        return

    with open(UNIT_PATH, "r", encoding="utf-8") as f:
        unit = json.load(f)

    print(f"\n=== Генерация озвучки для: {unit.get('title')} ===")
    print(f"Голос: {VOICE}\n")

    # 1. Текст урока (Ридер)
    for item in unit.get("text", []):
        text = item.get("target", "").strip()
        audio_rel = item.get("audio", "").strip()
        if text and audio_rel:
            await generate_speech(text, VOICE, os.path.join(PUBLIC_DIR, audio_rel))

    # 2. Слова (Спеллер)
    for item in unit.get("words", []):
        word = item.get("target", "").strip()
        audio_rel = item.get("audio", "").strip()
        if word and audio_rel:
            await generate_speech(word, VOICE, os.path.join(PUBLIC_DIR, audio_rel))

    # 3. Предложения (Пазл)
    for item in unit.get("sentences", []):
        sentence = item.get("target", "").strip()
        audio_rel = item.get("audio", "").strip()
        if sentence and audio_rel:
            await generate_speech(sentence, VOICE, os.path.join(PUBLIC_DIR, audio_rel))

    print("\n=== Все аудиофайлы для Unit 3 успешно созданы! ===")


if __name__ == "__main__":
    asyncio.run(main())